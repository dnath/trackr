from webunit.utility import Upload
from random import random

from funkload.FunkLoadTestCase import FunkLoadTestCase

class Simple(FunkLoadTestCase):

    def setUp(self):
        self.server_url = self.conf_get('main', 'url')
        self.get(self.server_url+'/login/perf_login?fb_token=CAACEdEose0cBALRkcUXTbxq2wyPVaiQe0yVNX3JUSFCKOOcV0Ww8A2RYHfqtZBXwZA1HyFteHjgQqGwhAJZBQZCxEMi6Lhl6NZBxHfZBoLgOymVeY8jooZAZAbad86QnwWGtPez8UPdoYDdHOCdJmEFWnHceUeVmRRKuUo1XYIJ1uJOhtlCwq7WfqHyoWlusmpEZD')

    def test_simple(self):
	#users= [ 13472,13473, 13474 ,14458 ,13476, 14459 , 13476 , 14460 ,13477,14461 ]
	#goal_instances=[16545,34843, 41776 , 42428 ,46476 , 52283 ,70102 ,91300 0,91360, 93470]
	goals= [5592 , 6265 ,6207 , 8428 ,6603 , 7679 , 4935 , 6107 , 6442, 7713]
	#pages = range(1,10)
	results = []
	results.append(self.get(self.server_url+'/login/perf_login?fb_token=CAACEdEose0cBANV3uZATzLsJEAZCDN9QyAuXR5QqGvc4CfsNbqU6jQSV0Q33MozFR87lgb4uXaSZCNQ9JE0JkXHK6yTZCtaZC4oJ8JqPdjVf8PwtFJqSqckFtZCHEtHZCdcO0SENbaL1HGqk165nZCOqrq0W0lIyHcAtnPYTbjudKqZCqqYjKIe2KBV5ZChWycZBZC4ZD'))
	results.append(self.get(self.server_url+'/goals'))
	results.append(self.post(self.server_url+"/goals",params=[['utf8', '\xe2\x9c\x93'],
								  ['goal[title]','test goal '],
								  ['goal[picture]',Upload('')]
	]))
	results.append(self.post(self.server_url+"/goal_instances",params=[["goal_instance[start_date(1i)]",2013],["goal_instance[start_date(2i)]",12],["goal_instance[start_date(3i)]",6],["goal_instance[end_date(1i)]",2013],["goal_instance[end_date(2i)]",12],["goal_instance[end_date(3i)]",7],["goal_instance[is_complete]",False],["goal_instance[cheer_ons]",0],["goal_instance[goal_id]",5592]]))
	results.append(self.get(self.server_url+'/logout'))
	#results.append(self.get(self.server_url+'/login/perf_login?fb_token=CAACEdEose0cBAA4IZA1dkTl1CPul8VGGqzt8OvKRpmINSehrLMXE03JJoaFvZCWKQ16FiKoPykJVtKX1w6VclBjH9lpfkg0kgOWgYvl3MmxQnEc3AZAtCG3Kx314pVUzzZAvmnquuS1StQMZCS42SAmnQEZB4mg9SOqYRMslfA8SS4JSsPGgXuZAojohVmhZB2RVzcjUmOTeCgZDZD'))
	#results.append(self.get(self.server_url+'/goal_instances?user_id=13289'))
	#results.append(self.get(self.server_url+'/goal_instances/14753'))
	#results.append(self.get(self.server_url+'/logout'))
	#results.append(self.get(self.server_url+'/friends/index'))
        
	for result in results:
		#res2 = self.get(self.server_url+'/goals?page='+str(page))
		#res2 = self.get(server_url+'/goal_instances?user_id='+str(user))
		#res2 = self.get(server_url+'/goal_instances/'+str(goal_instance))
       		self.assertEqual(result.code, 200)
    
    def tearDown(self):
	#self.get(self.server_url+'/logout')
	pass

if __name__ in ('main', '__main__'):

    unittest.main()
