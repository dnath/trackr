from random import random

from funkload.FunkLoadTestCase import FunkLoadTestCase

class Simple(FunkLoadTestCase):

    def setUp(self):
        self.server_url = self.conf_get('main', 'url')
        self.get(self.server_url+'/login/perf_login?fb_token=CAACEdEose0cBAG6bZCRCkU0VMDbhoAqq5jbzqX6gpOwcRRpZCDQjZBN7g3MWXzeJqKVhG7LbqSnkS4XEfgT3nFmZAV4vbr3EkCalvShcQrP0lZBwbc8FzcW6j5NSTmp0kquyZChE5GyJuLyaoVQDT1kX3ZCFefbJgFSJr2B1tzr5Je0o2AIVbARJcEskoLEM9eYZBDM0ZCnbIyQZDZD')

    def test_simple(self):
	#users= [ 13472,13473, 13474 ,14458 ,13476, 14459 , 13476 , 14460 ,13477,14461 ]
	#goal_instances=[16545,34843, 41776 , 42428 ,46476 , 52283 ,70102 ,91300 ,91360, 93470]
	#goals= [5592 , 6265 ,6207 , 8428 ,6603 , 7679 , 4935 , 6107 , 6442, 7713]
	#pages = range(1,10)
	results = []
        server_url = self.server_url
	#results.append(self.get(self.server_url+'/login/perf_login?fb_token=CAACEdEose0cBAA4IZA1dkTl1CPul8VGGqzt8OvKRpmINSehrLMXE03JJoaFvZCWKQ16FiKoPykJVtKX1w6VclBjH9lpfkg0kgOWgYvl3MmxQnEc3AZAtCG3Kx314pVUzzZAvmnquuS1StQMZCS42SAmnQEZB4mg9SOqYRMslfA8SS4JSsPGgXuZAojohVmhZB2RVzcjUmOTeCgZDZD'))
	#results.append(self.get(self.server_url+'/goal_instances?user_id=13289'))
	#results.append(self.get(self.server_url+'/goal_instances/14753'))
	#results.append(self.get(self.server_url+'/logout'))
	results.append(self.get(self.server_url+'/friends/index'))
        
	for result in results:
		#res2 = self.get(self.server_url+'/goals?page='+str(page))
		#res2 = self.get(server_url+'/goal_instances?user_id='+str(user))
		#res2 = self.get(server_url+'/goal_instances/'+str(goal_instance))
       		self.assertEqual(result.code, 200)
    
    def tearDown(self):
	#self.get(self.server_url+'/logout')
	pass

if __name__ in ('main', '__main__'):

    unittest.main()
